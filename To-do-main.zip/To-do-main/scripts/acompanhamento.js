// Recuperar as tarefas do localStorage
const tarefasSalvas = localStorage.getItem('tarefas');
const tarefas = tarefasSalvas ? JSON.parse(tarefasSalvas) : [];

// Exibir as tarefas na outra página
tarefas.forEach((value) => {
    // Faça o que for necessário para exibir as tarefas na outra página
    console.log(value.nome, value.prioridade, value.descricao, value.status);
});
