class Data {
    constructor() {
        this.dataAtual = new Date();
    }

    getDia() {
        return this.dataAtual.getDay();
    }

    getMes() {
        return this.dataAtual.getMonth();
    }

    getAno() {
        return this.dataAtual.getFullYear();
    }
}

function verificaSemana(dia) {
    if (dia >= 1 && dia <= 5) {
        return `Dia ${dia}: Você está no meio da semana. Continue firme!`;
    } else if (dia === 6) {
        return "Sábado, um dia para relaxar e recarregar as energias.";
    } else if (dia === 0 || dia === 7) {
        return "Domingo, aproveite para descansar e se preparar para a próxima semana.";
    } else {
        return "Dia não válido. Insira um número de 1 a 7 para representar os dias da semana.";
    }
    
}

function mainData() {
    const minhaData = new Data();
    const dia = minhaData.getDia();
    
    const mes = minhaData.getMes();
    const ano = minhaData.getAno();

    const diaSemana = verificaSemana(dia);
    
    const span = document.getElementById('data');
    span.innerHTML = ' ';
    const texto = document.createElement('p');
    texto.textContent = `${diaSemana}`;
    span.appendChild(texto);

    console.log(`Hoje é ${diaSemana}, dia ${dia} de ${mes} de ${ano}.`);
}
